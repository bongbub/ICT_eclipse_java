/*6. 계정생성(System 계정에서) 1. ~ 2.*/

/* DBeaver에서는 Oracle 하위에 있는 Schemas를 새로고침하면 
자동으로 생성된 계정이 보인다. */

-- 오라클 설치(SYSTEM/ORACLE) 
-- SYSTEM계정에서 계정 생성
-- hr : sql developer-system_01계정에서 계정생성안해도 되고, 3.락해제 5.비밀번호변경만 한다.

-- 1. 계정생성 : jsp_pj_ict05 계정생성
-- create user <계정이름> identified by <계정암호> default tablespace users;
create user  jsp_pj_ict05 identified by tiger default tablespace users;

-- 2. 사용자 권한 부여
-- grant [시스템 권한] to [계정];
grant connect, resource, create view to jsp_pj_ict05;


-- 3. 락 해제
-- alter user <계정이름> account unlock;
alter user jsp_pj_ict05 account unlock;

-- 4. 계정 잘못만든 경우 계정, 객체 삭제하기 
-- drop user <계정이름> cascade;
-- drop user jsp_pj_ict05 cascade; 

-- 5. 패스워드 변경
-- alter user <계정이름> identified by <패스워드>;
-- alter user jsp_pj_ict05 identified by tiger; 

------------------------------------------------------------------------------------------------------

/*7. 테이블 생성*/
-- jsp_pj_ict05 계정에서 작업
-- 회원정보 테이블
DROP TABLE mvc_customer_tbl  CASCADE CONSTRAINTS;
CREATE TABLE mvc_customer_tbl(
    user_id         VARCHAR2(20)    PRIMARY KEY,    	-- ID
	user_password   VARCHAR2(20)    NOT NULL,          	-- 수정, 삭제용 비밀번호
	user_name   	VARCHAR2(50)    NOT NULL,          	-- 이름
	user_birthday   DATE            NOT NULL,          	-- 생년월일    
	user_address    VARCHAR2(50)    NOT NULL,          	-- 주소
	user_hp         VARCHAR2(13),                      	-- 핸드폰      
	user_email      VARCHAR2(50)    NOT NULL,          	-- 이메일
	user_regdate    TIMESTAMP       DEFAULT sysdate    	-- 가입일
); 
-- 테이블 생성했다면, 꼭 해당 스키마를 새로고침을 해야 하위의 테이블 목록에 생성된 것이 보임

SELECT * FROM MVC_CUSTOMER_TBL;

-------------------------

-- jsp_pj_ict05 계정에서 작업
-- 게시판 테이블
DROP TABLE mvc_board_tbl CASCADE CONSTRAINT;
CREATE TABLE mvc_board_tbl (
	b_num		number(7)		PRIMARY KEY,		-- 글번호
	b_title 	varchar2(100)	NOT NULL,			-- 글제목
	b_content 	clob 			NOT NULL,			-- 글내용
	b_writer	varchar2(30)	NOT NULL,			-- 작성자
	b_password	varchar2(30)	NOT NULL,			-- 수정, 삭제용 비밀번호
	b_readCnt	NUMBER(6)		DEFAULT 0,			-- 조회수
	b_regDate 	DATE			DEFAULT sysdate,	-- 작성일
	b_comment_count number(6)	DEFAULT 0			-- 댓글 개수
);

SELECT * FROM mvc_board_tbl ORDER BY b_num desc;
SELECT count(*) FROM mvc_board_tbl;

-- 게시글 입력(다건) -> 목록 확인용   ==> 실행엔 declare부터 end까지 다 잡아서 실행
DECLARE -- 선언문(프로시저)
	i 	NUMBER := 1; 	-- 변수 i에 1을 대입
BEGIN
	WHILE i <= 991 LOOP
		INSERT INTO mvc_board_tbl(b_num, b_title, b_content, b_writer, b_password, b_readCnt, b_regDate, b_comment_count)
			VALUES (i,'글제목'||i, '글내용'||i, '작성자'||i, 1234, 0, sysdate, 0 );
		i := i+1;
	END LOOP;
END;

COMMIT;

-- 게시글 목록

SELECT * 
  FROM 
  	(SELECT A.*							-- A 테이블에서 모든 것을 가져와
		, rownum AS rn
		FROM 
		  	(SELECT * FROM mvc_board_tbl
				ORDER BY b_num DESC)  A		-- 내림차순
	)
 WHERE rn BETWEEN 11 AND  20;				-- 1페이지 : rn 1~10, /2페이지 : rn 11~20 /3페이지 : rn : 21~30


-- 게시글 상세 페이지
SELECT * FROM mvc_board_tbl
 WHERE b_num = 991;
 
-- 조회수
UPDATE MVC_BOARD_TBL
	SET b_readCnt = b_readCnt + 1
WHERE b_num = 199;	-- 현재번호에 맞을 때만 조회수 + 1
COMMIT;


-- 게시글 수정 삭제 버튼 클릭시 -> 비밀번호 인증처리
SELECT count(*) AS cnt FROM MVC_BOARD_TBL
 WHERE b_num = 1
   AND b_password = 1234;


-- 게시글 수정
UPDATE mvc_board_tbl
   SET b_password = '1111'
   	 , b_title='제목입니당 ㅋ'
   	 , b_content='곰세마리가 한 집에 있어 아빠곰 엄마곰 애기곰 아빠곰은 뚱뚱해 엄마곰은 날씬해 애기곰은 너무 귀여워 으쓱 으쓱 잘 한다'
 WHERE b_num = 991;
COMMIT;


-- 게시글 삭제
DELETE FROM MVC_BOARD_TBL
 WHERE b_num = 991;


-- 게시글 추가
INSERT INTO mvc_board_tbl(b_num, B_TITLE, B_WRITER, B_CONTENT, B_PASSWORD, B_COMMENT_COUNT, B_READCNT, B_REGDATE)
	values(992, '제목', '작성자', '내용', '1234', 0, 0, sysdate);




-- 내용삭제 --------------------------------
DELETE FROM MVC_CUSTOMER_TBL ;

DELETE FROM mvc_board_tbl;


