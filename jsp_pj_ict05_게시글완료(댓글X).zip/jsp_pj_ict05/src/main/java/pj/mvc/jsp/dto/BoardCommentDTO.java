package pj.mvc.jsp.dto;

public class BoardCommentDTO {

}
