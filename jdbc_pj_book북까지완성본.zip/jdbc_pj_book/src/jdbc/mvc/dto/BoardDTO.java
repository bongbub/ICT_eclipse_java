package jdbc.mvc.dto;

public class BoardDTO {

}
